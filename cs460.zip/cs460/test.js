function myFunction() {
	document.getElementById("test").innerHTML="SB"
}