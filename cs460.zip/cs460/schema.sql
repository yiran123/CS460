
DROP DATABASE myphotoshare;
CREATE DATABASE myphotoshare;
USE myphotoshare;



CREATE TABLE Users (
    uid int(4)  AUTO_INCREMENT,
    email varchar(255) UNIQUE,
    password varchar(255) NOT NULL,
    fname VARCHAR(255),
    lname VARCHAR(255), 
    birthday DATE, 
    hometown VARCHAR(255), 
    gender CHAR,
  CONSTRAINT users_pk PRIMARY KEY (uid)
);

CREATE TABLE Photos
(
  pid int(4)  AUTO_INCREMENT,
  uid int(4) NOT NULL,
  imgdata longblob,
  caption VARCHAR(255),
  INDEX upid_idx (uid),
  CONSTRAINT photos_pk PRIMARY KEY (pid),
  FOREIGN KEY (uid) REFERENCES Users(uid) on delete cascade
);

INSERT INTO Users (email, password) VALUES ('test@bu.edu', 'test');
INSERT INTO Users (email, password) VALUES ('test1@bu.edu', 'test');
INSERT INTO Users (email, password) VALUES ('test2@bu.edu', 'test');

CREATE TABLE Albums(
    aid int(4) AUTO_INCREMENT PRIMARY KEY,  
    Name VARCHAR(255) NOT NULL,
    pid int(4) NOT NULL
    Adate datetime NOT NULL DEFAULT NOW(), 
    uid INT(4) NOT NULL, 
    FOREIGN KEY (uid) REFERENCES Users(uid) on delete CASCADE,
    FOREIGN KEY (pid) REFERENCES Photos(pid)
    );

CREATE TABLE albumPhoto(     
    aid INT(4) NOT NULL,     
    pid INT(4),     
    PRIMARY KEY(aid),     
    FOREIGN KEY(aid) REFERENCES Albums(aid) on delete cascade, 
    FOREIGN key (pid) REFERENCES photos(pid)
    );

CREATE TABLE userAlbum(
    uid INT(4) NOT NULL,      
    aid INT(4),      
    PRIMARY KEY(uid),     
    FOREIGN KEY(aid) REFERENCES Albums(aid),     
    FOREIGN KEY(uid) REFERENCES Users(uid) on delete cascade
    );

CREATE TABLE Comments(
    uid INT(4) NOT NULL,
    pid INT(4) NOT NULL,
    content VARCHAR(255),
    PRIMARY KEY (uid, pid),
    FOREIGN KEY (uid) REFERENCES Users(uid),
    FOREIGN KEY (pid) REFERENCES photos(pid) on delete cascade
    );

CREATE TABLE Tags(
    tid INT(4) AUTO_INCREMENT PRIMARY KEY,
    word VARCHAR(255)
    );

CREATE TABLE photoTags(
    tid INT(4),
    uid INT(4),
    pid INT(4),
    PRIMARY KEY (pid),
    FOREIGN KEY (tid) REFERENCES Tags(tid) on delete cascade,
    FOREIGN KEY (uid) REFERENCES Users(uid),
    FOREIGN KEY (pid) REFERENCES Photos(pid)  on delete cascade,
    CONSTRAINT selftag CHECK (Photos.uid=photoTags.uid)
    );

CREATE TABLE Friends(
    uid INT(4),
    fid INT(4),
    FOREIGN KEY (uid) REFERENCES Users(uid) on delete cascade,
    FOREIGN KEY (fid) REFERENCES Users(uid) on delete cascade,
    CONSTRAINT differentid CHECK (uid!=fid)
    );

CREATE TABLE Likes(
    uid INT(4),
    pid INT(4),
    FOREIGN KEY (uid) REFERENCES Users(uid),
    FOREIGN KEY (pid) REFERENCES Photos(pid) on delete CASCADE
    );

INSERT INTO Users (email, password) VALUES ('test@bu.edu', 'test');
INSERT INTO Users (email, password) VALUES ('test1@bu.edu', 'test');
INSERT INTO Users (email, password) VALUES ('test2@bu.edu', 'test');
